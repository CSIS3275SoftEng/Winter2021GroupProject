package com.example.pracSpringboot1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracSpringboot1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
