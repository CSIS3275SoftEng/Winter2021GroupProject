package com.example.pracSpringboot1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracSpringboot1Application {

	public static void main(String[] args) {
		SpringApplication.run(PracSpringboot1Application.class, args);
	}

}
